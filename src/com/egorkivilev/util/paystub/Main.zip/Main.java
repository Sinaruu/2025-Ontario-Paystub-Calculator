package com.egorkivilev.util.paystub;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    static Scanner sc;
    static UserStubs user;
    static DecimalFormat numberFormat = new DecimalFormat("#.00");

    static void showMenu() {
        System.out.println("===========================");
        System.out.println("| PAYSTUB CALCULATOR v1.0 |");
        System.out.println("===========================");
        System.out.println("1. Add paystub");
        System.out.println("2. Review paystub");
        System.out.println("3. Delete paystub");
        System.out.println("4. Show paystubs");
        System.out.println("5. Personal Settings");
        System.out.println("6. Exit");
    }

    static void addPaystub() throws PayException {
        String input;
        float hours;
        System.out.print("Enter amount of hours worked (in decimal): ");
        input = sc.nextLine();
        hours = Util.parseFloat(input);
        if(hours < 3) throw new PayException("The amount of hours must be equal or greater than 3");
        user.addPaystub(hours);
    }

    static void reviewPaystub() throws PayException {
        String choice;
        int index;
        System.out.print("Enter the paystub index: ");
        choice = sc.nextLine();
        index = Util.parseInt(choice);
        user.printPaystub(index);
        System.out.print(Util.colourText("Enter any value to continue...", "COLOUR_YELLOW"));
        sc.nextLine();
    }

    static void deletePaystub() throws PayException {
        String choice;
        int index;
        System.out.print("Enter the paystub index: ");
        choice = sc.nextLine();
        index = Util.parseInt(choice);
        user.deletePaystub(index);
        System.out.println(Util.colourText("Paystub with index " + index + " deleted successfully.", "COLOUR_GREEN"));
        System.out.print(Util.colourText("Enter any value to continue...", "COLOUR_YELLOW"));
        sc.nextLine();
    }

    static void showPaystubs() {
        user.printPaystub();
        System.out.print(Util.colourText("Enter any value to continue...", "COLOUR_YELLOW"));
        sc.nextLine();
    }

    static void personalSettings() throws PayException {
        System.out.println(Util.colourText("\n> Personal Settings:", "COLOUR_YELLOW"));
        System.out.println(Util.colourText("1. Change PayRate ($" + numberFormat.format(Util.payRate) + "/hr)", "COLOUR_YELLOW"));
        System.out.println(Util.colourText("2. Exit", "COLOUR_YELLOW"));
        String choice;
        int index;
        System.out.print("Enter your choice: ");
        choice = sc.nextLine();
        index = Util.parseInt(choice);
        switch(index) {
            case 1 -> {
                String newRate;
                System.out.print("Enter new pay rate: ");
                newRate = sc.nextLine();
                float rate = Util.parseFloat(newRate);
                Util.changePayRate(rate);
                System.out.println(Util.colourText("Pay rate changed to $" + numberFormat.format(rate) + "/hr", "COLOUR_GREEN"));
                System.out.print(Util.colourText("Enter any value to continue...", "COLOUR_YELLOW"));
                sc.nextLine();
            }
            case 2 -> {
                System.out.println("Left Settings.");
            }
            default -> throw new PayException("Incorrect choice.");
        }
    }

    static void exit() {
        System.out.println("Goodbye!");
        System.exit(0);
    }

    static UserStubs loadPaystubs() throws PayException {
        System.out.println("e");
        ArrayList<Paystub> paystubs = new ArrayList<Paystub>();
        ArrayList<String> fields = new ArrayList<String>();
        String line;
        int nlines = 0;
        try {
            System.out.println("a");
            File file = new File("UserStubs.csv");
            Scanner input = new Scanner(file);

            while (input.hasNextLine()) {
                System.out.println("b");
                line = input.nextLine();
                //System.out.println(line);
                fields = Util.parseLine(line);
                //if (nlines==0) Util.getNCols(line);
                if (nlines!=0) {
                    paystubs.add(Paystub.create(fields));
                }
                nlines++;
            }
            input.close();

            System.out.println(paystubs.isEmpty());

            if(paystubs.isEmpty()) {
                return new UserStubs();
            }

            return new UserStubs(paystubs);
        } catch (FileNotFoundException e) {
            return new UserStubs();
        } catch (InputMismatchException e) {
            throw new PayException("Incorrect input.");
        }
    }

    static void loadSettings() {
        ArrayList<String> values = new ArrayList<String>();
        ArrayList<String> fields = new ArrayList<String>();

        String line;
        int nlines = 0;
        try {
            File file = new File("UserSettings.csv");
            Scanner input = new Scanner(file);

            while (input.hasNextLine()) {
                line = input.nextLine();
                //System.out.println(line);
                fields = Util.parseLine(line);
                //if (nlines==0) Util.getNCols(line);
                if (nlines!=0) {
                    values = fields;
                }
                nlines++;
            }
            input.close();

            Util.changePayRate(Float.parseFloat(values.getFirst()));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws PayException {
        sc = new Scanner(System.in);
        user = loadPaystubs();

        loadSettings();

        while(true) {
            showMenu();
            try {
                String input;
                System.out.print("Enter your choice: ");
                input = sc.nextLine();

                int choice = Util.parseInt(input);

                switch(choice) {
                    case 1 -> addPaystub();
                    case 2 -> reviewPaystub();
                    case 3 -> deletePaystub();
                    case 4 -> showPaystubs();
                    case 5 -> personalSettings();
                    case 6 -> exit();
                }
            }
            catch(PayException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
