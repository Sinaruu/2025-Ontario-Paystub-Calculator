package com.egorkivilev.util.paystub;

import java.util.ArrayList;

public class Util {
    public static final String COLOUR_RESET = "\u001B[0m";
    public static final String COLOUR_RED = "\u001B[31m";
    public static final String COLOUR_GREEN = "\u001B[32m";
    public static final String COLOUR_YELLOW = "\u001B[33m";
    public static final String COLOUR_BLUE = "\u001B[34m";
    public static final String COLOUR_MAGENTA = "\u001B[35m";
    public static final String COLOUR_CYAN = "\u001B[36m";
    public static final String COLOUR_WHITE = "\u001B[37m";

    public static float getTaxRate(float grossPay) {
        if(grossPay >= 235676) return 53.53f;
        else if(grossPay >= 220001) return 49.85f;
        else if(grossPay >= 165431) return 48.29f;
        else if(grossPay >= 150001) return 44.97f;
        else if(grossPay >= 106718) return 43.41f;
        else if(grossPay >= 102140) return 37.91f;
        else if(grossPay >= 98464) return 33.89f;
        else if(grossPay >= 86697) return 31.48f;
        else if(grossPay >= 53360) return 29.65f;
        else if(grossPay >= 49232) return 24.15f;
        else if(grossPay >= 15001) return 20.05f;
        else {return 0.0f;}
    }

    public static int parseInt(String input) throws PayException {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            throw new PayException("Invalid entry: Enter an integer between 1 and 6");
        }
    }

    public static float parseFloat(String input) throws PayException {
        try {
            return Float.parseFloat(input);
        } catch (NumberFormatException e) {
            throw new PayException("Invalid entry: Enter an integer between 1 and 6");
        }
    }

    public static String colourText(String line, String colour) {
        switch(colour) {
            case "COLOUR_RED" -> {return COLOUR_RED + line + COLOUR_RESET;}
            case "COLOUR_BLUE" -> {return COLOUR_BLUE + line + COLOUR_RESET;}
            case "COLOUR_CYAN" -> {return COLOUR_CYAN + line + COLOUR_RESET;}
            case "COLOUR_GREEN" -> {return COLOUR_GREEN + line + COLOUR_RESET;}
            case "COLOUR_MAGENTA" -> {return COLOUR_MAGENTA + line + COLOUR_RESET;}
            case "COLOUR_WHITE" -> {return COLOUR_WHITE + line + COLOUR_RESET;}
            case "COLOUR_YELLOW" -> {return COLOUR_YELLOW + line + COLOUR_RESET;}
            default -> {return line;}
        }
    }

    public static void changePayRate(float payRate) {
        Util.payRate = payRate;
    }

    static ArrayList<String> parseLine(String line) {
        ArrayList<String> fields = new ArrayList<String>();
        int index = 0;
        String field = "";
        boolean inQuotes = false;
        char ch;
        for (int i = 0; i < line.length(); i++) {
            ch = line.charAt(i);
            if (ch == '"') {
                inQuotes = !inQuotes;
            } else if (ch == ',' && !inQuotes) {
                fields.add(index++, field.strip());
                field = "";
            } else {
                field = field + ch;
            }
        }
        fields.add(index++, field.strip());
        return fields;
    }

    static int getNCols(String line) {
        //System.out.println(line);
        String[] split = line.split(",");
        return split.length;
    }

    public static final float EI_RATE = 1.64f;
    public static final float CPP_RATE = 5.95f;
    public static float payRate = 17.70f;
}
